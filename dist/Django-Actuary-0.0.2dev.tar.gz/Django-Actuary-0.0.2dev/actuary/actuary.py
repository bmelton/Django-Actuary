def j(self):
    print "Hello world"
