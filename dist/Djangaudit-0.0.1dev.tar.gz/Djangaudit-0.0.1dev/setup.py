from distutils.core import setup

setup(
    name='Djangaudit',
    version='0.0.1dev',
    author='Barry Melton',
    author_email='barry.melton@gmail.com',
    packages=['djangaudit',], 
    url='http://pypi.python.org/pypi/Djangaudit/',
    license='LICENSE.txt',
    description='Django auditing application.',
    install_requires=[
    ],
)
